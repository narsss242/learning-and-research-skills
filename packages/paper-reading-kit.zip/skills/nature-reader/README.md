<!-- Adapted for portable sharing, 2026-10-30; see SOURCE.md for provenance and changes. -->
# `nature-reader` 技能

[English](README_EN.md)

`nature-reader` 用于把论文 PDF、DOI、arXiv、出版社 HTML 或粘贴文本转换为可回溯的全文 Markdown 阅读材料，包含中英对照、图表定位、可直接阅读的公式和 source map。

## 适合用它做什么

- 制作论文全文中英对照 Markdown。
- 在首次实质性讨论处插入对应图表和图注翻译。
- 为每段文本、图、表建立页码和来源锚点。
- 将公式渲染为 Markdown 数学块，并为每个独立公式建立 `E...` 锚点。
- 扫描件或无法可靠转写的公式会保留原图裁剪，不会用猜测出的 LaTeX 替代原式。
- 从 PDF、HTML 或预印本文本中提取可复核阅读材料。
- 生成适合后续写作、汇报或引用核查的阅读底稿。

## 典型请求

- “把这篇 PDF 做成中英对照全文 Markdown。”
- “翻译并解读这篇论文，图表要放在对应正文附近。”
- “根据 DOI 获取论文内容，生成带 source map 的阅读材料。”

## 你需要提供

- PDF、DOI、arXiv 链接、出版社 HTML、题名或粘贴文本。
- 输出目录和是否需要图片裁剪。
- 是否保留英文原文、中文翻译、图表、表格和翻译备注。

## 产出

- `paper.md`：全文阅读材料。
- `source_map.json`：页码、文本块和图表来源映射。
- `translation_notes.md`：术语、无法确认内容和翻译说明。
- `assets/`：图表、裁剪图片和必要附件。
- `assets/equations/`：低置信度或图片化公式的原始裁剪（按需生成）。

## 边界

- 默认以 Markdown 为中心，不默认生成交互式问答面板。
- 扫描 PDF、双栏错序或版权受限全文可能需要额外人工校对；图片化公式会优先显示原图并标记转写置信度。
- 无法合法获取全文时，会基于可用摘要/元数据说明限制。

## 相关技能

- `nature-downloader`：先合法获取 PDF 或 HTML 全文。
- `nature-paper2ppt`：把阅读材料转成中文汇报 PPT。
- `nature-citation`：从阅读材料中抽取需要引用支撑的 claim。
